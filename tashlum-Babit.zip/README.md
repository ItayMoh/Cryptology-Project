# Cryptology Course Project  
Secure access to dataset of images. Password access to the data.  
An image must be enrypted/decr by CAST-256 in CBC mode + image verification of decrypted image with  
MAC(Message authentication code) + secret key delivery with EC El-Gamal


Before running the code install:  
pip install bitarray  
pip install pycryptodone  

The password of the data set is "12345"  
in the files there is a images with name "test1 test2....." you can test the code with this images.  

Thanks.  